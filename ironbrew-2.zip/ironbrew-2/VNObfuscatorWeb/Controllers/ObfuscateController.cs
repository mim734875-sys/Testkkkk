using Microsoft.AspNetCore.Mvc;
using IronBrew2;
using IronBrew2.Obfuscator;
using System.IO;
using System.Text;

namespace VNObfuscatorWeb.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ObfuscateController : ControllerBase
    {
        [HttpPost]
        public async Task<IActionResult> Obfuscate([FromForm] IFormFile? file, [FromForm] string? code, [FromForm] ObfuscationSettings settings)
        {
            try
            {
                string inputCode = "";
                
                if (file != null && file.Length > 0)
                {
                    using var reader = new StreamReader(file.OpenReadStream());
                    inputCode = await reader.ReadToEndAsync();
                }
                else if (!string.IsNullOrEmpty(code))
                {
                    inputCode = code;
                }
                else
                {
                    return Ok(new { success = false, error = "Please provide either a file or code to obfuscate." });
                }

                string tempPath = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString());
                Directory.CreateDirectory(tempPath);

                try
                {
                    string inputFile = Path.Combine(tempPath, "input.lua");
                    System.IO.File.WriteAllText(inputFile, inputCode, Encoding.GetEncoding(28591));

                    if (settings == null)
                    {
                        settings = new ObfuscationSettings();
                    }

                    if (!IB2.Obfuscate(tempPath, inputFile, settings, out string error))
                    {
                        return Ok(new { success = false, error = $"Obfuscation failed: {error}" });
                    }

                    string outputFile = Path.Combine(tempPath, "out.lua");
                    if (!System.IO.File.Exists(outputFile))
                    {
                        return Ok(new { success = false, error = "Output file was not generated." });
                    }

                    string obfuscatedCode = System.IO.File.ReadAllText(outputFile);
                    
                    return Ok(new { success = true, code = obfuscatedCode });
                }
                finally
                {
                    if (Directory.Exists(tempPath))
                    {
                        Directory.Delete(tempPath, true);
                    }
                }
            }
            catch (Exception ex)
            {
                return Ok(new { success = false, error = $"Error: {ex.Message}" });
            }
        }
    }
}
