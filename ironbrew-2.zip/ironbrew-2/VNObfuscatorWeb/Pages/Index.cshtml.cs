using Microsoft.AspNetCore.Mvc.RazorPages;

namespace VNObfuscatorWeb.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
