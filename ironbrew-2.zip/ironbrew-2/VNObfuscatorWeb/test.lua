print("Hello from VN Obfuscate!")
local x = 10
local y = 20
print("Sum:", x + y)
