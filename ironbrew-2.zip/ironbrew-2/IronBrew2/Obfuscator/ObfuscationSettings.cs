namespace IronBrew2.Obfuscator
{
        public class ObfuscationSettings
        {
                public bool EncryptStrings { get; set; }
                public bool EncryptImportantStrings { get; set; }
                public bool ControlFlow { get; set; }
                public bool BytecodeCompress { get; set; }
                public int DecryptTableLen { get; set; }
                public bool PreserveLineInfo { get; set; }
                public bool Mutate { get; set; }
                public bool SuperOperators { get; set; }
                public int MaxMiniSuperOperators { get; set; }
                public int MaxMegaSuperOperators { get; set; }
                public int MaxMutations { get; set; }
                public bool AntiDebug { get; set; }
                public bool AntiTamper { get; set; }
                public bool AntiDecode { get; set; }
                public bool UseCustomSymbols { get; set; }
                
                public ObfuscationSettings()
                {
                        EncryptStrings = true;
                        EncryptImportantStrings = true;
                        ControlFlow = true;
                        BytecodeCompress = true;
                        DecryptTableLen = 1000;
                        PreserveLineInfo = false;
                        Mutate = true;
                        SuperOperators = true;
                        MaxMegaSuperOperators = 300;
                        MaxMiniSuperOperators = 300;
                        MaxMutations = 500;
                        AntiDebug = true;
                        AntiTamper = true;
                        AntiDecode = true;
                        UseCustomSymbols = true;
                }
        }
}