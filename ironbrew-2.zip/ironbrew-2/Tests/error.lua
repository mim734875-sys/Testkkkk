print'no'
print(pcall(function() string.dump(loadstring) end))
print'no agan'
error'yes'