while wait() do 
	spawn(function() print'asd' end)
end