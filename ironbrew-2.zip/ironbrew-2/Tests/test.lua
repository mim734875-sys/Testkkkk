if a or b then print('asd') end

local a = 1
print(a == 1, a < 1, a > 1, a ~= 1, a <= 2, a >= 2)