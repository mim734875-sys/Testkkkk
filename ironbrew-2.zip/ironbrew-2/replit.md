# IronBrew2 - Lua 5.1 Obfuscator

## Overview

IronBrew2 is a VM-based obfuscation system for Lua 5.1 code. The project provides multiple interfaces for code obfuscation: a core library (`IronBrew2`), a command-line interface (`IronBrew2 CLI`), and a web application (`VNObfuscatorWeb`). The system transforms Lua scripts into obfuscated versions using virtual machine techniques, making the code harder to reverse-engineer while maintaining functionality.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Multi-Project Solution Structure

**Problem**: Need to provide Lua obfuscation functionality through multiple interfaces (library, CLI, web).

**Solution**: Three-tier project architecture:
- `IronBrew2` - Core obfuscation library (.NET 7.0)
- `IronBrew2 CLI` - Command-line interface (.NET Core 3.1)
- `VNObfuscatorWeb` - Web interface (ASP.NET Core 7.0)

**Rationale**: Separating the core logic from presentation layers allows code reuse and supports different deployment scenarios (standalone CLI tool vs. web service).

**Pros**:
- Core logic is reusable across all interfaces
- Each interface can be deployed independently
- Clear separation of concerns

**Cons**:
- Multiple target frameworks require separate maintenance
- Cross-project dependencies need careful versioning

### Frontend Architecture

**Problem**: Provide a web-based interface for obfuscation.

**Solution**: ASP.NET Core Razor Pages application with minimal client-side dependencies.

**Implementation**:
- Server-side rendering with Razor Pages
- jQuery for client-side validation and interaction
- jQuery Validation (unobtrusive) for form validation
- Scoped CSS for component styling

**Rationale**: Razor Pages provides a simpler development model than full MVC for page-focused scenarios, appropriate for a tool with limited UI complexity.

**Pros**:
- Straightforward page-based routing
- Built-in validation support
- Minimal JavaScript complexity

**Cons**:
- Less suitable for highly interactive UIs
- Limited client-side state management

### Backend Architecture

**Problem**: Process and obfuscate Lua code efficiently.

**Solution**: Library-based architecture with dependency injection support in the web layer.

**Implementation**:
- Core obfuscation logic in `IronBrew2` library
- ASP.NET Core web application references the library
- Standard .NET logging infrastructure
- Configuration through appsettings.json

**Rationale**: Keeping obfuscation logic in a separate library enables testing in isolation and reuse across different interfaces.

### Text Encoding Support

**Problem**: Lua scripts may contain various character encodings.

**Solution**: Integration of `System.Text.Encoding.CodePages` package.

**Rationale**: Ensures proper handling of non-ASCII characters and legacy encodings that may appear in Lua scripts.

**Version Strategy**: 
- .NET 7.0 projects use version 7.0.0
- .NET Core 3.1 projects use preview version 4.6.0-preview.18571.3

### Application Configuration

**Problem**: Different configuration needs for development and production environments.

**Solution**: ASP.NET Core configuration system with environment-specific files.

**Implementation**:
- `appsettings.json` - Base configuration
- `appsettings.Development.json` - Development overrides with detailed errors
- Environment-specific logging levels

**Rationale**: Standard ASP.NET Core pattern enables easy environment-specific configuration without code changes.

### Static Asset Management

**Problem**: Efficiently serve client-side libraries and static files.

**Solution**: ASP.NET Core static file middleware with scoped CSS compilation.

**Implementation**:
- Client libraries (jQuery, jQuery Validation) in wwwroot/lib
- Scoped CSS compilation for component isolation
- Static web assets bundling for production

**Rationale**: Built-in ASP.NET Core features handle common web asset scenarios without additional build tooling.

## External Dependencies

### NuGet Packages

- **System.Text.Encoding.CodePages** (7.0.0 / 4.6.0-preview)
  - Purpose: Extended character encoding support for Lua scripts
  - Used across all projects

### Client-Side Libraries

- **jQuery** (version in wwwroot/lib)
  - Purpose: DOM manipulation and AJAX support
  - License: MIT (OpenJS Foundation)

- **jQuery Validation**
  - Purpose: Client-side form validation
  - License: MIT

- **jQuery Validation Unobtrusive**
  - Purpose: Integration with ASP.NET Core validation attributes
  - License: MIT (.NET Foundation)

### Runtime Dependencies

- **.NET 7.0** - Primary runtime for web application and core library
- **.NET Core 3.1** - Runtime for CLI application
- **ASP.NET Core 7.0** - Web framework for VNObfuscatorWeb

### Development Tools

- **NuGet** - Package management
- **MSBuild** - Build system
- **Razor** - View engine for web UI