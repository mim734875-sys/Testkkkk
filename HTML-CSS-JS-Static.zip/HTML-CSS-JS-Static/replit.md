# MonLuaProtector v2.0

## Tổng quan
MonLuaProtector là ứng dụng web bảo vệ script Lua với mã hóa và xác thực nâng cao. Người dùng có thể tải lên hoặc nhập code Lua, và hệ thống sẽ tạo một link an toàn được lưu trữ trên GitHub Gists.

## Các tính năng mới (v2.0)

### Giao diện (GUI)
- ✅ Thiết kế hiện đại với gradient màu tím-xanh
- ✅ Hệ thống tab (Tải File, Nhập Mã, Thông Tin)
- ✅ Icons đẹp từ Font Awesome
- ✅ Responsive trên mobile
- ✅ Loading states và error handling rõ ràng
- ✅ Feedback tức thì (copy link notification)

### Bảo mật (v2.2+)

### Đơn giản & An toàn:

1. **Custom Script Names** - Người dùng tự đặt tên script
   - Format: `a-z`, `0-9`, dấu gạch ngang `-`
   - VD: `my-script`, `security-shield`, `rapid-loader`
   - Max 50 ký tự, không được trùng
   - Không cần token hay signature

2. **User-Agent Verification** - Chỉ Roblox client
   - Ngăn chặn curl/wget/postman/browser access
   - Layer bảo vệ chính

3. **Rate Limiting** - Giới hạn upload
   - Max 10 request/phút trên mỗi IP
   - Ngăn chặn abuse

4. **Persistent Storage** - Lưu vào file
   - Script mapping được lưu vào `data/storage.json`
   - Không mất dữ liệu khi server restart

### Thêm các tính năng:
- **Input Validation** - Code tối đa 1MB
- **Cache Control** - No-cache headers
- **Security Headers** - X-Content-Type-Options, X-Frame-Options
- **Audit Logging** - Log failed access attempts

## Kiến trúc
- **Frontend**: HTML5 + Tailwind CSS + Vanilla JS (không dependencies)
- **Backend**: Express.js (Node.js)
- **Storage**: GitHub Gists (Private)
- **Security**: Token + User-Agent + Rate limiting

## File cấu trúc
```
.
├── server.js              # Express server chính
├── public/
│   └── index.html        # Frontend (UI đẹp mới)
├── package.json          # Dependencies
└── vercel.json           # Config Vercel (tương thích)
```

## Cách sử dụng

### Cho Developer
1. **Nhập tên script** (VD: `my-script`, `security-shield`)
   - Chỉ dùng: a-z, 0-9, dấu gạch ngang (-)
   - Max 50 ký tự, không được trùng
   
2. **Upload file Lua hoặc nhập mã trực tiếp**
   - Upload file: click "Upload" button
   - Hoặc paste code vào textarea
   
3. **Nhấn "Tạo RawLink"**
   - Hệ thống tạo Gist trên GitHub
   
4. **Copy link và chia sẻ cho Roblox client**
   - Link format: `domain/raw/{script-name}`
   - VD: `https://example.com/raw/my-script`
   - Chỉ Roblox client mới có thể dùng

### Security Flow
1. User nhập tên script + code
2. Server validate tên (a-z, 0-9, -, max 50 ký tự)
3. Server tạo Gist trên GitHub (private)
4. Lưu mapping: `script-name → {gistId, createdAt, ipAddress}`
5. Return URL: `domain/raw/{script-name}`
6. Khi client request:
   - ✅ Kiểm tra script name tồn tại
   - ✅ Kiểm tra User-Agent là Roblox
   - ✅ Nếu OK → Trả về code | ❌ Nếu không → Lỗi 403

## Environment Variables
- `GITHUB_TOKEN` - Token GitHub API (bắt buộc để upload gist)
- `PORT` - Cổng server (mặc định: 5000)
- `ADMIN_TOKEN` - Token admin để xem danh sách scripts (tùy chọn, để debug)

## Dependencies
- express: ^4.18.2 - Web framework
- axios: ^1.6.8 - HTTP client (GitHub API)
- fs-extra: ^11.1.1 - File system utilities
- uuid: ^9.0.1 - Tạo ID duy nhất
- crypto: ^1.0.0 - Tạo token bảo vệ (built-in Node.js)

## Lần cập nhật gần đây

### v2.2 (Simple & Clean - Không cần token)
- ✅ **Bỏ token & signature** - Chỉ cần tên script
  - URL format: `/raw/{script-name}` (đơn giản hơn)
  - Không cần `?token=...&sig=...`
  - User-Agent verification vẫn bảo vệ (Roblox only)
  
- ✅ Simplified server
  - Bỏ tokenStorage, tokenMap, token generation
  - Bỏ signature verification logic
  - Chỉ giữ: script name check + User-Agent check + Rate limit
  
- ✅ Persistent Storage
  - Script mappings lưu vào `data/storage.json`
  - Format: `{script-name: {gistId, createdAt, ipAddress}}`

### v2.1 (Bảo mật nâng cao)
- Token + Signature (HMAC-SHA256)
- Token Expiration (30 ngày)
- Security headers (X-Content-Type-Options, X-Frame-Options)

### v2.0 (Ban đầu)
- Thiết kế GUI hoàn toàn mới với Tailwind CSS
- Token-based authentication
- Rate limiting
- Error messages đa ngôn ngữ
