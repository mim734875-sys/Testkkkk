import express from "express";
import axios from "axios";
import { randomUUID } from "crypto";
import fs from "fs-extra";
import path from "path";
import { fileURLToPath } from "url";
import crypto from "crypto";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use(express.static("public"));

// Storage files
const DATA_FILE = path.join(__dirname, "data", "storage.json");
const TOKEN_FILE = path.join(__dirname, "data", "tokens.json");

// Ensure data directory exists
await fs.ensureDir(path.join(__dirname, "data"));

// Load persistent storage
let storage = {};
let tokenMap = {};

async function loadStorage() {
  try {
    if (await fs.pathExists(DATA_FILE)) {
      storage = await fs.readJSON(DATA_FILE);
    }
    if (await fs.pathExists(TOKEN_FILE)) {
      tokenMap = await fs.readJSON(TOKEN_FILE);
    }
  } catch (err) {
    console.error("Failed to load storage:", err.message);
  }
}

async function saveStorage() {
  try {
    await fs.writeJSON(DATA_FILE, storage, { spaces: 2 });
    await fs.writeJSON(TOKEN_FILE, tokenMap, { spaces: 2 });
  } catch (err) {
    console.error("Failed to save storage:", err.message);
  }
}

// Load storage on startup
await loadStorage();

// Rate limiting
const requestLimits = {};

function generateToken() {
  return crypto.randomBytes(32).toString("hex");
}

function generateFriendlyName() {
  const adjectives = ["quick", "swift", "bright", "smart", "solid", "strong", "brave", "sharp", "keen", "agile"];
  const nouns = ["script", "code", "module", "asset", "crypto", "shield", "vault", "secure", "guard", "armor"];
  const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
  const noun = nouns[Math.floor(Math.random() * nouns.length)];
  const number = Math.floor(Math.random() * 10000);
  return `${adj}-${noun}-${number}`;
}

function rateLimit(ip, maxRequests = 5, windowMs = 60000) {
  if (!requestLimits[ip]) {
    requestLimits[ip] = {
      count: 0,
      resetTime: Date.now() + windowMs
    };
  }

  const limit = requestLimits[ip];
  
  if (Date.now() > limit.resetTime) {
    limit.count = 0;
    limit.resetTime = Date.now() + windowMs;
  }

  limit.count++;
  return limit.count <= maxRequests;
}

function createSecuritySignature(name, token, secret = process.env.SECURITY_SECRET || "default-secret") {
  return crypto
    .createHmac("sha256", secret)
    .update(`${name}:${token}`)
    .digest("hex");
}

function validateSecuritySignature(name, token, signature, secret = process.env.SECURITY_SECRET || "default-secret") {
  const expectedSignature = createSecuritySignature(name, token, secret);
  return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature));
}

// Serve main page
app.get("/", async (req, res) => {
  const html = await fs.readFile(path.join(__dirname, "public", "index.html"), "utf8");
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
  res.status(200).send(html);
});

// Upload handler
app.post("/upload", async (req, res) => {
  const ip = req.ip || req.connection.remoteAddress;

  // Rate limiting
  if (!rateLimit(ip, 10, 60000)) {
    return res.status(429).json({ error: "⏱️ Quá nhiều yêu cầu. Vui lòng chờ 1 phút" });
  }

  const { text, name } = req.body || {};
  if (!text) return res.status(400).json({ error: "❌ Mã code không được để trống" });
  if (!name) return res.status(400).json({ error: "❌ Vui lòng nhập tên script" });
  
  // Validate name format (only lowercase letters, numbers, hyphens)
  if (!/^[a-z0-9\-]{1,50}$/.test(name)) {
    return res.status(400).json({ error: "❌ Tên script chỉ được chứa chữ cái thường, số, và dấu gạch ngang (-)" });
  }

  // Check if name already exists
  if (storage[name]) {
    return res.status(409).json({ error: "❌ Tên này đã được sử dụng. Vui lòng chọn tên khác" });
  }
  
  if (text.length > 100 * 1024 * 1024) {
    return res.status(400).json({ error: "❌ Code quá lớn (tối đa 100MB)" });
  }

  const token = process.env.GITHUB_TOKEN;
  if (!token) return res.status(500).json({ error: "❌ Server chưa được cấu hình GitHub token" });

  try {
    const id = randomUUID();
    const response = await axios.post(
      "https://api.github.com/gists",
      {
        files: { [`${id}.lua`]: { content: text } },
        public: false,
        description: `MonLuaProtector Gist - ${name}`
      },
      {
        headers: { 
          Authorization: `token ${token}`,
          "User-Agent": "MonLuaProtector/2.1"
        }
      }
    );

    const gistId = response.data.id;
    
    // Use custom name and generate security tokens
    const accessToken = generateToken();
    const expiryTime = Date.now() + (30 * 24 * 60 * 60 * 1000); // 30 days
    const signature = createSecuritySignature(name, accessToken);

    // Store mapping
    storage[name] = {
      gistId: gistId,
      createdAt: Date.now(),
      ipAddress: ip
    };

    tokenMap[accessToken] = {
      name: name,
      gistId: gistId,
      createdAt: Date.now(),
      expiresAt: expiryTime,
      signature: signature
    };

    // Save to persistent storage
    await saveStorage();

    const protocol = req.headers["x-forwarded-proto"] || "http";
    const host = req.headers.host;
    const rawLink = `${protocol}://${host}/raw/${name}?token=${accessToken}&sig=${signature}`;
    
    console.log(`✅ Script uploaded: ${name} (from ${ip})`);
    
    res.json({ 
      id: gistId,
      name: name,
      token: accessToken,
      signature: signature,
      expiresAt: new Date(expiryTime).toISOString(),
      raw: rawLink
    });
  } catch (err) {
    console.error("Gist upload failed:", err.message);
    res.status(500).json({ error: "❌ Lỗi khi tải lên Gist. Vui lòng thử lại" });
  }
});

// Enhanced raw endpoint with multi-layer security
app.get("/raw/:name", async (req, res) => {
  const name = req.params.name;
  const token = req.query.token;
  const signature = req.query.sig;
  const ua = (req.headers["user-agent"] || "").toLowerCase();
  const ip = req.ip || req.connection.remoteAddress;

  // Security Layer 1: Validate name exists
  if (!storage[name]) {
    return res.status(404).json({ 
      error: "❌ Không tìm thấy resource này" 
    });
  }

  // Security Layer 2: Token verification
  if (!token || !tokenMap[token]) {
    return res.status(403).json({ 
      error: "❌ Token không hợp lệ hoặc không được cung cấp" 
    });
  }

  const tokenData = tokenMap[token];

  // Security Layer 3: Check token expiration
  if (Date.now() > tokenData.expiresAt) {
    // Clean up expired token
    delete tokenMap[token];
    await saveStorage();
    return res.status(403).json({ 
      error: "❌ Token đã hết hạn" 
    });
  }

  // Security Layer 4: Verify name-token relationship
  if (tokenData.name !== name) {
    console.warn(`[SECURITY] Token-name mismatch: token for ${tokenData.name} used for ${name}`);
    return res.status(403).json({ 
      error: "❌ Token không hợp lệ cho resource này" 
    });
  }

  // Security Layer 5: Signature verification
  if (!signature) {
    return res.status(403).json({ 
      error: "❌ Signature không được cung cấp" 
    });
  }

  try {
    if (!validateSecuritySignature(name, token, signature)) {
      console.warn(`[SECURITY] Signature validation failed for ${name}`);
      return res.status(403).json({ 
        error: "❌ Signature không hợp lệ" 
      });
    }
  } catch (err) {
    console.warn(`[SECURITY] Signature validation error for ${name}: ${err.message}`);
    return res.status(403).json({ 
      error: "❌ Lỗi xác thực signature" 
    });
  }

  // Security Layer 6: User-Agent verification (Roblox only)
  if (!ua.includes("roblox")) {
    console.warn(`[SECURITY] Non-Roblox access attempt to ${name} from IP ${ip}`);
    return res.status(403).json({ 
      error: "❌ Chỉ Roblox client được phép truy cập" 
    });
  }

  try {
    const gistId = storage[name].gistId;
    const gistUrl = `https://api.github.com/gists/${gistId}`;
    const response = await axios.get(gistUrl);
    
    if (!response.data.files) {
      return res.status(404).json({ error: "❌ Không tìm thấy file" });
    }

    const files = response.data.files;
    const file = Object.values(files)[0];
    
    if (!file) {
      return res.status(404).json({ error: "❌ Không tìm thấy nội dung" });
    }

    const code = file.content;

    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.send(code);
  } catch (err) {
    console.error("Gist fetch failed:", err.message);
    res.status(404).json({ error: "❌ Không tìm thấy hoặc Gist đã bị xóa" });
  }
});

// Admin: List all protected scripts (for reference only)
app.get("/admin/scripts", (req, res) => {
  const adminToken = req.query.admin_token;
  if (adminToken !== process.env.ADMIN_TOKEN) {
    return res.status(403).json({ error: "❌ Không được phép" });
  }

  const scripts = Object.entries(storage).map(([name, data]) => ({
    name,
    gistId: data.gistId,
    createdAt: new Date(data.createdAt).toISOString(),
    createdFrom: data.ipAddress
  }));

  res.json(scripts);
});

// Clean up expired tokens periodically
setInterval(async () => {
  const now = Date.now();
  let cleaned = 0;

  for (const [token, data] of Object.entries(tokenMap)) {
    if (now > data.expiresAt) {
      delete tokenMap[token];
      cleaned++;
    }
  }

  if (cleaned > 0) {
    console.log(`[CLEANUP] Removed ${cleaned} expired tokens`);
    await saveStorage();
  }
}, 60000 * 60); // Check every hour

app.listen(PORT, "0.0.0.0", () => {
  console.log(`🛡️  MonLuaProtector Server running on http://0.0.0.0:${PORT}`);
  console.log(`📊 Security features enabled: Token + Signature + Expiration + User-Agent + Rate Limit`);
});
